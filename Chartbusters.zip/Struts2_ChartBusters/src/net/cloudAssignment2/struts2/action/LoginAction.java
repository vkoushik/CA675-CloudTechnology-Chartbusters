package net.cloudAssignment2.struts2.action;

import java.sql.SQLException;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.Statement;
import java.sql.DriverManager;

import com.opensymphony.xwork2.ActionSupport;

public class LoginAction extends ActionSupport {
	private String genre;
	private String url = "jdbc:hive2://54.194.79.213:10000/default";

	private String username;
	private String password;
	private String z;
	private String driverName = "com.amazon.hive.jdbc3.HS2Driver";

	public String execute() {
		z = loadContentFromJDBC();
		if (this.username.equals("admin")
				&& this.password.equals("123")) {
			return "success";
		} else {
			addActionError(getText("error.login"));
			return "error";
		}

	}

	public String updateGenre(){
		z = loadContentFromJDBC(this.genre);
		return "success";
	}

	private String loadContentFromJDBC(){
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
		Connection con;
		try {
			con = DriverManager.getConnection(url, "hadoop", "");

			Statement stmt;
			stmt = con.createStatement();
			String tableName = "songsandgenre";
			// show tables
			String sql = "show tables '" + tableName + "'";
			System.out.println("Running: " + sql);
			ResultSet res = stmt.executeQuery(sql);
			if (res.next()) {
				System.out.println(res.getString(1));
			}
			// describe table
			sql = "describe " + tableName;
			sql = "Select top 10 * from " + tableName;// + " limit 10";
			System.out.println("Running: " + sql);
			res = stmt.executeQuery(sql);
			return parseData(res);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
// Query Running
	private String loadContentFromJDBC(String gen){
		try {
			Class.forName(driverName);
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.exit(1);
		}
		Connection con;
		try {
			con = DriverManager.getConnection(url, "hadoop", "");

			Statement stmt;
			stmt = con.createStatement();
			String tableName = "songsandgenre";
			// show tables
			String sql = "Select top 100 * from " + tableName + " where LOWER(genre) LIKE '%" + gen.toLowerCase() + "%'";// + " limit 10";
			System.out.println("Running: " + sql);
			ResultSet res = stmt.executeQuery(sql);
			return parseData(res);
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return "";
	}
	
	
//Displaying of Result on browser
	private String parseData(ResultSet res){
		StringBuilder sb = new StringBuilder();
		sb.append("<div style=\"width:100%;  height:60%; overflow:auto\">");
		sb.append("<table border=\"1\" style=\"width:100%;  height:60%; overflow:auto\">");


		try {
			ResultSetMetaData rsmd = res.getMetaData();
			sb.append("<tr>");
			for(int i = 1; i <= rsmd.getColumnCount(); i++)
				sb.append("<th>" + rsmd.getColumnName(i) + "</th>");
			sb.append("</tr>");
			
			while (res.next()) {
				sb.append("<tr>");
				for(int i = 1; i <= rsmd.getColumnCount(); i++)
					sb.append("<td>" + res.getString(i) + "</td>");
				sb.append("</tr>");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		sb.append("</table>");
		sb.append("</div>");
		return sb.toString();
	}
	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	/**
	 * @return the z
	 */
	public String getZ() {
		return z;
	}

	/**
	 * @param z the z to set
	 */
	public void setZ(String z) {
		this.z = z;
	}

	/**
	 * @return the genre
	 */
	public String getGenre() {
		return genre;
	}

	/**
	 * @param genre the genre to set
	 */
	public void setGenre(String genre) {
		this.genre = genre;
	}
}

